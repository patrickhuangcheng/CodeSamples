#ifndef DELEGATE_H
#define DELEGATE_H
#include <list>
class DelegateBase
{
public:
	virtual void NoParamDelegate() = 0;
	virtual void OneBoolDelegate(bool bOK) = 0;
	virtual void OneIntDelegate(int Num) = 0;
};

template<typename O, typename T>
class LevelDelegate : public DelegateBase
{
	typedef void (T::*VoidDelegate)();
	typedef void (T::*BoolDelegate)(bool);
	typedef void (T::*IntDelegate)(int);

public:
	LevelDelegate(O* pObj = NULL, VoidDelegate pFun = NULL)
		:m_pVoidDelegate(pFun), m_pObj(pObj)
	{}

	LevelDelegate(O* pObj = NULL, BoolDelegate pFun = NULL)
		:m_pBoolDelegate(pFun), m_pObj(pObj)
	{}

	LevelDelegate(O* pObj = NULL, IntDelegate pFun = NULL)
		:m_pIntDelegate(pFun), m_pObj(pObj)
	{}
	virtual void NoParamDelegate()
	{
		if (m_pVoidDelegate != NULL
			&& m_pObj != NULL)
		{
			(m_pObj->*m_pVoidDelegate)();
		}
	}

	virtual void OneBoolDelegate(bool bOK)
	{
		if (m_pBoolDelegate != NULL
			&& m_pObj != NULL)
		{
			(m_pObj->*m_pBoolDelegate)(bOK);
		}
	}

	virtual void OneIntDelegate(int Num)
	{
		if (m_pIntDelegate != NULL
			&& m_pObj != NULL)
		{
			(m_pObj->*m_pIntDelegate)(Num);
		}
	}

private:
	VoidDelegate m_pVoidDelegate;
	BoolDelegate m_pBoolDelegate;
	IntDelegate  m_pIntDelegate;
	O* m_pObj;
};

template<typename O, typename T>
LevelDelegate<O, T>* MakeVoidDelegate(O* pObject, void (T::*pVoidDelegate)())
{
	return new LevelDelegate<O, T>(pObject, pVoidDelegate);
}

template<typename O, typename T>
LevelDelegate<O, T>* MakeOneBoolDelegate(O* pObject, void (T::*pBoolDelegate)(bool))
{
	return new LevelDelegate<O, T>(pObject, pBoolDelegate);
}

template<typename O, typename T>
LevelDelegate<O, T>* MakeOneIntDelegate(O* pObject, void (T::*pIntDelegate)(int))
{
	return new LevelDelegate<O, T>(pObject, pIntDelegate);
}

class NoParamEvent
{
public:
	NoParamEvent() :m_Delegate(nullptr) {}
	~NoParamEvent()
	{
		delete m_Delegate;
	}

	void operator = (DelegateBase* p)
	{
		m_Delegate = p;
	}

	void operator()()
	{
		if (m_Delegate)
			m_Delegate->NoParamDelegate();
	}

private:
	DelegateBase* m_Delegate;
};
class OneParamEvent
{
public:
	OneParamEvent() :m_Delegate(nullptr) {}

	~OneParamEvent()
	{
		delete m_Delegate;
	}

	void operator = (DelegateBase* p)
	{
		m_Delegate = p;
	}

	void operator()(bool bIsTrue)
	{
		if (m_Delegate)
			m_Delegate->OneBoolDelegate(bIsTrue);
	}

	void operator()(int Num)
	{
		if (m_Delegate)
			m_Delegate->OneIntDelegate(Num);
	}

private:
	DelegateBase* m_Delegate;
};


class OneParamMulticastEvent
{

public:
	~OneParamMulticastEvent()
	{
		ITR itr = m_arDelegates.begin();
		while (itr != m_arDelegates.end())
		{
			delete *itr;
			++itr;
		}
		m_arDelegates.clear();
	}

	void operator += (DelegateBase* p)
	{
		m_arDelegates.push_back(p);
	}

	void operator -= (DelegateBase* p)
	{
		ITR itr = find(m_arDelegates.begin(), m_arDelegates.end(), p);
		m_arDelegates.erase(itr);
	}

	void operator()(int Num)
	{
		ITR itrTemp = m_arDelegates.begin();
		while (itrTemp != m_arDelegates.end())
		{
			(*itrTemp)->OneIntDelegate(Num);
			++itrTemp;
		}
	}


private:
	std::list<DelegateBase*> m_arDelegates;
	typedef std::list<DelegateBase*>::iterator ITR;

};

class TimeManager {

public:
	TimeManager(DelegateBase* InNoParamCallback, float ActionChangeTime, float WaitTime = 0.f, bool IsLoop = false)
		:m_Delegate(InNoParamCallback),
		m_fActionChangeTime(ActionChangeTime),
		m_fActionChangeWait(WaitTime),
		m_bIsloop(IsLoop)
	{}

	~TimeManager()
	{
		delete m_Delegate;
	}
	void Update(float CurrentTime)
	{
		if (CurrentTime - m_fActionChangeTime >= m_fActionChangeWait)
		{
			if (m_Delegate)
				m_Delegate->NoParamDelegate();

			if (m_bIsloop)
			{
				m_fActionChangeTime = CurrentTime;
			}
		}
	}
private:
	DelegateBase* m_Delegate;
	float m_fActionChangeTime;
	const float m_fActionChangeWait;
	bool  m_bIsloop;
};
#endif
