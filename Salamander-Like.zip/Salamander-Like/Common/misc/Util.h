#ifndef UTIL_H
#define UTIL_H
//------------------------------------------------------------------------
//
//  Name: util.h
//
//  Desc: misc utility functions and constants
//
//  Author: HUANG Cheng
//
//------------------------------------------------------------------------

#include <math.h>
#include <string>
#include <vector>
#include <limits>
#include <cassert>

//a few useful constants
const int     MaxInt = (std::numeric_limits<int>::max)();
const double  MaxDouble = (std::numeric_limits<double>::max)();
const double  MinDouble = (std::numeric_limits<double>::min)();
const float   MaxFloat = (std::numeric_limits<float>::max)();
const float   MinFloat = (std::numeric_limits<float>::min)();

const double   Pi = 3.14159;
const double   TwoPi = Pi * 2;
const double   HalfPi = Pi / 2;
const double   QuarterPi = Pi / 4;

//returns the maximum of two values
template <class T>
inline T MaxOf(const T& a, const T& b)
{
	if (a > b) return a; return b;
}

//returns the minimum of two values
template <class T>
inline T MinOf(const T& a, const T& b)
{
	if (a < b) return a; return b;
}

//clamps the first argument between the second two
template <class T, class U, class V>
inline void Clamp(T& arg, const U& minVal, const V& maxVal)
{
	assert(((double)minVal < (double)maxVal) && "<Clamp>MaxVal < MinVal!");

	if (arg < (T)minVal)
	{
		arg = (T)minVal;
	}

	if (arg > (T)maxVal)
	{
		arg = (T)maxVal;
	}
}

//----------------------------------------------------------------------------
//  some random number functions. from Buckland's AI book
//----------------------------------------------------------------------------

//returns a random integer between x and y
inline int   RandInt(int x, int y)
{
	assert(y >= x && "<RandInt>: y is less than x");
	return rand() % (y - x + 1) + x;
}

//returns a random double between zero and 1
inline double RandFloat() { return ((rand()) / (RAND_MAX + 1.0)); }

inline double RandInRange(double x, double y)
{
	return x + RandFloat()*(y - x);
}

//returns a random bool
inline bool   RandBool()
{
	if (RandFloat() > 0.5) return true;

	else return false;
}

//returns a random double in the range -1 < n < 1
inline double RandomClamped() { return RandFloat() - RandFloat(); }



//rounds a double up or down depending on its value
inline int Rounded(double val)
{
	int    integral = (int)val;
	double mantissa = val - integral;

	if (mantissa < 0.5)
	{
		return integral;
	}

	else
	{
		return integral + 1;
	}
}

//rounds a double up or down depending on whether its 
//mantissa is higher or lower than offset
inline int RoundUnderOffset(double val, double offset)
{
	int    integral = (int)val;
	double mantissa = val - integral;

	if (mantissa < offset)
	{
		return integral;
	}

	else
	{
		return integral + 1;
	}
}

//compares two real numbers. Returns true if they are equal
inline bool isEqual(float a, float b)
{
	if (fabs(a - b) < 1E-12)
	{
		return true;
	}

	return false;
}

inline bool isEqual(double a, double b)
{
	if (fabs(a - b) < 1E-12)
	{
		return true;
	}

	return false;
}


template <class T>
inline double Average(const std::vector<T>& v)
{
	double average = 0.0;

	for (unsigned int i = 0; i < v.size(); ++i)
	{
		average += (double)v[i];
	}

	return average / (double)v.size();
}


inline double StandardDeviation(const std::vector<double>& v)
{
	double sd = 0.0;
	double average = Average(v);

	for (unsigned int i = 0; i < v.size(); ++i)
	{
		sd += (v[i] - average) * (v[i] - average);
	}

	sd = sd / v.size();

	return sqrt(sd);
}


template <class container>
inline void DeleteSTLContainer(container& c)
{
	for (container::iterator it = c.begin(); it != c.end(); ++it)
	{
		delete *it;
		*it = NULL;
	}
}

template <class map>
inline void DeleteSTLMap(map& m)
{
	for (map::iterator it = m.begin(); it != m.end(); ++it)
	{
		delete it->second;
		it->second = NULL;
	}
}

// class PseudoRandomDistributor
// {
// public:
// 	PseudoRandomDistributor(int Value = 0)
// 		: CurCValue(Value),
// 		CValue(Value),
// 		DieSize(100000)	
// 	{
// 		Clamp(CurCValue, 0, DieSize);
// 		Clamp(CValue, 0, DieSize);
// 	}
// 
// 	bool IsHappen()
// 	{
// 		if ((int)(std::rand() % DieSize) + 1 <= CurCValue)
// 		{
// 			CurCValue = CValue;
// 			return true;
// 		}
// 		else
// 		{
// 			CurCValue += CurCValue;
// 			return false;
// 		}
// 	}
// private:
// 	// scale 100000 times
// 	int CurCValue;
// 	const int CValue;
// 	const int DieSize;
// };
#endif