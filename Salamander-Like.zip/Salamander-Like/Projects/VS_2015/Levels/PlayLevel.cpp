#include "Levels\PlayLevel.h"
#include "GameEntities\GameEntity.h"
#include "GameEntities\PlayerBase.h"
#include "GameEntities\BGEntity.h"
#include "GameEntities\BulletEntity.h"
#include "GameEntities\EnemyPlayer.h"
#include "GameEntities\Meteorite.h"
#include "GameEntities\Powerup.h"
#include "GameSystem\WaveSpawner.h"

PlayLevel::~PlayLevel()
{
	ClearLevel();
}

void PlayLevel::Update()
{
	if (!m_bStarted) return;

	if (!pPlayer) return;

	pPlayer->Update();

	if (!pWaveSpawner) return;

	pWaveSpawner->Update();


	if (m_fLevelFinishTime > 0 && Simple2D::GetGameTime() - m_fLevelFinishTime > 1.f)
		StartLevelCallback();

	std::list<EnemyPlayer*>& AllEnemies = AutoList<EnemyPlayer>::GetAllMembers();
	std::list<EnemyPlayer*>::iterator curEnemy;
	for (curEnemy = AllEnemies.begin(); curEnemy != AllEnemies.end();)
	{
		if ((*curEnemy)->IsExpired())
		{
			curEnemy = AllEnemies.erase(curEnemy);
		}
		else
		{
			(*curEnemy)->Update();
			if (!(*curEnemy)->IsDead())
			{
				// Collision
				bool IsPlayerDead = false;
				if ((*curEnemy)->IsOverlapped(pPlayer))
				{
					(*curEnemy)->ApplyDamage(9, pPlayer);
					IsPlayerDead = pPlayer->ApplyDamage();
				}
			}
			++curEnemy;
		}
		
	}

	std::list<BulletEntity*>& AllBullets = AutoList<BulletEntity>::GetAllMembers();
	std::list<BulletEntity*>::iterator curBullet;
	for (curBullet = AllBullets.begin(); curBullet != AllBullets.end();)
	{
		(*curBullet)->Update();
		if (!(*curBullet)->IsWithinScreen())
		{
			curBullet = AllBullets.erase(curBullet);
			continue;
		}
		// Collision
		bool IsBulletDead = false;
		if ((*curBullet)->EntityTeam() == BaseGameEntity::red_team)
		{// shot by the player
			for (curEnemy = AllEnemies.begin(); curEnemy != AllEnemies.end();)
			{
				if(!(*curEnemy)->IsDead())
				if ((*curEnemy)->IsOverlapped((*curBullet)))
				{
					(*curEnemy)->ApplyDamage(1, (*curBullet)->GetInstigator());
					IsBulletDead = (*curBullet)->ApplyDamage();
				}
				if (IsBulletDead)
					break;
				++curEnemy;
			}
		}
		else if ((*curBullet)->EntityTeam() == BaseGameEntity::blue_team)
		{// shot by an enemy
			if ((*curBullet)->IsOverlapped(pPlayer))
			{
				IsBulletDead = (*curBullet)->ApplyDamage();
				pPlayer->ApplyDamage();
			}
		}
		if (IsBulletDead)
		{
			curBullet = AllBullets.erase(curBullet);
		}
		else
			++curBullet;
	}

	std::list<Meteorite*>& AllMeteorites = AutoList<Meteorite>::GetAllMembers();
	std::list<Meteorite*>::iterator curMeteorite;
	for (curMeteorite = AllMeteorites.begin(); curMeteorite != AllMeteorites.end(); ++curMeteorite)
	{
		(*curMeteorite)->Update();
		if ((*curMeteorite)->IsOverlapped(pPlayer))
		{
			pPlayer->ApplyDamage();
		}
		for (curBullet = AllBullets.begin(); curBullet != AllBullets.end();)
		{
			if ((*curMeteorite)->IsOverlapped((*curBullet)))
				curBullet = AllBullets.erase(curBullet);
			else
				++curBullet;
		}
	}

	std::list<Powerup*>& AllPowerups = AutoList<Powerup>::GetAllMembers();
	std::list<Powerup*>::iterator curPowerup;
	for (curPowerup = AllPowerups.begin(); curPowerup != AllPowerups.end();)
	{
		(*curPowerup)->Update();
		if ((*curPowerup)->IsOverlapped(pPlayer))
		{
			dynamic_cast< PlayerBase* >(pPlayer)->Upgrade();
			curPowerup = AllPowerups.erase(curPowerup);
		}
		else
			++curPowerup;
	}

	for (auto&& t : pBGImage) t->Update();


	if (GameConfig::m_bDebug && Simple2D::IsKeyPressed(Simple2D::KEY_SPACE))
	{
		dynamic_cast <PlayerBase*>(pPlayer)->OnPlayerReallyDie();
		LevelFinished();
	}

}

void PlayLevel::Render()
{

	for (auto&& t : pBGImage) t->Render();

	if (!pPlayer) return;

	pPlayer->Render();

	std::list<EnemyPlayer*>& AllEnemies = AutoList<EnemyPlayer>::GetAllMembers();
	std::list<EnemyPlayer*>::iterator curEnemy;
	for (curEnemy = AllEnemies.begin(); curEnemy != AllEnemies.end(); ++curEnemy)
	{
		(*curEnemy)->Render();
	}

	std::list<BulletEntity*>& AllBullets = AutoList<BulletEntity>::GetAllMembers();
	std::list<BulletEntity*>::iterator curBullet;
	for (curBullet = AllBullets.begin(); curBullet != AllBullets.end(); ++curBullet)
	{
		(*curBullet)->Render();
	}

	std::list<Meteorite*>& AllMeteorites = AutoList<Meteorite>::GetAllMembers();
	std::list<Meteorite*>::iterator curMeteorite;
	for (curMeteorite = AllMeteorites.begin(); curMeteorite != AllMeteorites.end(); ++curMeteorite)
	{
		(*curMeteorite)->Render();
	}

	std::list<Powerup*>& AllPowerups = AutoList<Powerup>::GetAllMembers();
	std::list<Powerup*>::iterator curPowerup;
	for (curPowerup = AllPowerups.begin(); curPowerup != AllPowerups.end(); ++curPowerup)
	{
		(*curPowerup)->Render();
	}

}

void PlayLevel::PostInitLevel()
{
// 	new Meteorite(Vector2D(m_cxClient * 3 / 4.f, m_cyClient / 3.f), Meteorite::medium2);
// 	new Meteorite(Vector2D(m_cxClient * 3 / 4.f, m_cyClient / 3.f), Meteorite::medium1);
// 	new Meteorite(Vector2D(m_cxClient * 3 / 4.f, m_cyClient / 3.f), Meteorite::small);
// 	new Meteorite(Vector2D(m_cxClient * 3 / 4.f, m_cyClient / 3.f), Meteorite::big);
// 	new Powerup(Vector2D(m_cxClient * 3 / 4.f, m_cyClient / 4.f));
// 	new Powerup(Vector2D(m_cxClient * 3 / 4.f, m_cyClient / 6.f));
	Level::PostInitLevel();

}

void PlayLevel::LevelFinished()
{
	m_fLevelFinishTime = Simple2D::GetGameTime();
}

void PlayLevel::ResetLevel()
{
	if (!ClearLevel()) return;

	m_fLevelFinishTime = 0.f;

	pPlayer = new PlayerBase(Vector2D(m_cxClient / 4.f, m_cyClient / 2.f), GameConfig::PLAYERSPEED, PlayerBase::newborn);
	pPlayer->EntityCallback = MakeVoidDelegate(this, &PlayLevel::LevelFinished);

	pBGImage[0] = new BGEntity(GameConfig::MOONLAYERRIGHT, GameConfig::MOONLAYERRIGHT, GameConfig::MOONLAYERVELOCITY, GameConfig::STARLAYERCLAMPX, GameConfig::MoonTex, 1.7f);
	dynamic_cast <BGEntity*>(pBGImage[0])->EnableBGUpdate();

	pBGImage[1] = new BGEntity(GameConfig::STARLAYERSTART, GameConfig::STARLAYERRIGHT, GameConfig::STARLAYERVELOCITY, GameConfig::STARLAYERCLAMPX, GameConfig::StarLayerTex);
	pBGImage[2] = new BGEntity(GameConfig::STARLAYERRIGHT, GameConfig::STARLAYERRIGHT, GameConfig::STARLAYERVELOCITY, GameConfig::STARLAYERCLAMPX, GameConfig::StarLayerTex);

	dynamic_cast <BGEntity*>(pBGImage[1])->SetTheOtherBGImage(dynamic_cast <BGEntity*>(pBGImage[2]));
	dynamic_cast <BGEntity*>(pBGImage[2])->SetTheOtherBGImage(dynamic_cast <BGEntity*>(pBGImage[1]));

	dynamic_cast <BGEntity*>(pBGImage[1])->EnableBGUpdate();
	   
	pWaveSpawner = new WaveSpawner();

}

bool PlayLevel::ClearLevel()
{

	std::list<BulletEntity*>& AllBullets = AutoList<BulletEntity>::GetAllMembers();
	std::list<BulletEntity*>::iterator curBullet;
	for (curBullet = AllBullets.begin(); curBullet != AllBullets.end();)
	{
		curBullet = AllBullets.erase(curBullet);
	}

	std::list<Meteorite*>& AllMeteorites = AutoList<Meteorite>::GetAllMembers();
	std::list<Meteorite*>::iterator curMeteorite;
	for (curMeteorite = AllMeteorites.begin(); curMeteorite != AllMeteorites.end();)
	{
		curMeteorite = AllMeteorites.erase(curMeteorite);
	}

	std::list<Powerup*>& AllPowerups = AutoList<Powerup>::GetAllMembers();
	std::list<Powerup*>::iterator curPowerup;
	for (curPowerup = AllPowerups.begin(); curPowerup != AllPowerups.end();)
	{
		curPowerup = AllPowerups.erase(curPowerup);
	}
	if (pPlayer != NULL) delete pPlayer;
	if (pWaveSpawner != NULL) delete pWaveSpawner;
	if (pBGImage != NULL) delete[] * pBGImage;
	return true;
}
