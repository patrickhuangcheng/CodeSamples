#ifndef BULLET_ENTITY_H
#define BULLET_ENTITY_H

#include "misc/autolist.h"
#include "MovingEntity.h"

class BulletEntity :	public MovingEntity,
						public AutoList<BulletEntity>
{
public:
	BulletEntity(
		Vector2D position,
		Vector2D velocity,
		const std::string & SpriteURL,
		MovingEntity* Instigator
	) :	MovingEntity(bullet_type, position, velocity, SpriteURL),
		m_Instigator(Instigator)
	{
		if (Instigator)
		{
			SetTeam(Instigator->EntityTeam());
		}
	}

	virtual ~BulletEntity() {};

	void Update();
	
	MovingEntity* GetInstigator() const { return m_Instigator; }
private:
	// Sender
	MovingEntity* m_Instigator;
};

#endif

