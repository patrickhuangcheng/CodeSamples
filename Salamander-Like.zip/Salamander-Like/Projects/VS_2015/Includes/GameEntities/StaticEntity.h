#ifndef STATIC_ENTITY_H
#define STATIC_ENTITY_H

#include "misc/autolist.h"
#include "GameEntities/GameEntity.h"

class StaticEntity : public BaseGameEntity,
					 public AutoList<StaticEntity>
{

public:
	StaticEntity(int Type, Vector2D position, float LifeTime, const std::string & SpriteURL)
		:BaseGameEntity(BaseGameEntity::GetNextValidID(), Type, SpriteURL, position, position)

	{}

	virtual ~StaticEntity() {}


};

#endif