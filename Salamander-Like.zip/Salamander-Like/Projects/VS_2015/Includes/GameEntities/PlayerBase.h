#ifndef PLAYER_BASE_H
#define PLAYER_BASE_H

#include "misc/autolist.h"
#include "MovingEntity.h"

class PlayerBase :	public MovingEntity,
					public AutoList<PlayerBase>
{
public:
	enum LEVEL { newborn, advance, ultimate };
	enum FIRERATE { slowFire, midFire, fastFire };
	enum STATE {none, flyingToPlayerStart, controlledByPlayer, destroyed};

protected:
	// for enemy
	PlayerBase(Vector2D position, Vector2D velocity, const std::string &  SpriteURL);

public:
	// for player
	PlayerBase(Vector2D position, Vector2D velocity, PlayerBase::LEVEL level);

	virtual ~PlayerBase();

	void Update();

	void Fire();

	void Upgrade(int grade = 1);

	void DownGrade(int grade = 1);
protected:
	bool CheckAmmo();

	void ShowDebugPosition();
public:

	virtual float OnDead();

protected:
	void OnRestoreEntity();
	virtual void RestoreEntity();
	Simple2D::Image* ExplosionImage;
public:
	void OnPlayerReallyDie();

private:
	void DetectControl();
	void UpdateControl();
	void ResetControl();
	bool isUPPressed;
	bool isDownPressed;
	bool isLeftPressed;
	bool isRightPressed;

	bool isFirePressed;

	LEVEL m_Grade;
	STATE m_State;
	const int m_MaxGrade;
	const int m_MaxLive;
	int m_Ammo;
	float m_LastFireTime;
	float m_DestroyedTime;
	Vector2D ExplotionImgPos;
	const Vector2D Up;
	const Vector2D Down;
	const Vector2D Left;
	const Vector2D Right;
};
#endif
