#ifndef MOVING_ENTITY_H
#define MOVING_ENTITY_H
#include <functional> 
#include "GameEntities/GameEntity.h"

class MovingEntity : public BaseGameEntity

{

public:
	
	MovingEntity(int Type, Vector2D position, Vector2D velocity, const std::string & SpriteURL)
		:BaseGameEntity(BaseGameEntity::GetNextValidID(), Type, SpriteURL, position, position),
		m_vVelocity(velocity),
		m_vClampX(GameConfig::ACTORCLAMPX),
		m_vClampY(GameConfig::ACTORCLAMPY)
	{}

	MovingEntity(int Type, Vector2D position, Vector2D velocity, const std::string & SpriteURL, Vector2D ClampX, Vector2D ClampY)
		:BaseGameEntity(BaseGameEntity::GetNextValidID(), Type, SpriteURL, position, position),
		m_vVelocity(velocity),
		m_vClampX(ClampX),
		m_vClampY(ClampY)
	{}

	virtual ~MovingEntity();

	//accessors
	Vector2D  Velocity()const { return m_vVelocity; }
	void      SetVelocity(const Vector2D& NewVel) { m_vVelocity = NewVel; }

	void AddMovement();
	void AddMovement(const Vector2D & delta_pos);

	/// Collision Interface Starts

	// Is overlapped with the other
	bool IsOverlapped(const MovingEntity &other);
	bool IsOverlapped(MovingEntity const *other);

	bool IsWithinScreen();

	///  Collision Interface Ends

protected:


	Vector2D    m_vVelocity;

	// for entities from right to left only
	bool IsReachedOtherSideofScr(const Vector2D& ClampX, bool IsFromRightToLeft = true);
	bool IsWithinScrHeight(const Vector2D& ClampY);
	Vector2D	m_vClampX;
	Vector2D	m_vClampY;
private:
	

	// Bounding box collision testing
	bool IsBoundingBoxOverlap(const MovingEntity &other);
	// Bounding circle collision testing
	bool IsBoundingCircleOverlap(const MovingEntity &other);
};


#endif