#ifndef METEORITE_H
#define METEORITE_H

#include "misc/autolist.h"
#include "MovingEntity.h"

class Meteorite : public MovingEntity,
				  public AutoList<Meteorite>
{
public:
	enum METEORITE { small, medium1, medium2, big };

	Meteorite(
		Vector2D position,
		METEORITE size
	) : Rot(GameConfig::METEOROTATION[size]),
		MovingEntity(
		obstacle_type, 
		position, 
		GameConfig::METEOSPEED[size], 
		GameConfig::MeteoriteTexes[size])

	{}
	virtual ~Meteorite();

	void Update();

private:
	const float Rot;
};

#endif