#ifndef GAME_ENTITY_H
#define GAME_ENTITY_H
//------------------------------------------------------------------------
//
//  Name: GameEntity.h
//
//  Desc: Base class to define a common interface for all game
//        entities
//
//  Author: HUANG Cheng
//
//------------------------------------------------------------------------
#include <vector>
#include <string>
#include <assert.h>
#include "2D/Vector2D.h"
#include "misc/util.h"
#include "misc/autolist.h"
#include "GameSystem\ShooterGame.h"
#include "Delegate.h"

class BaseGameEntity

{
public:

	enum EntityType
	{ 
		default_entity_type = -1, 
		body_type = 0, 
		bullet_type = 1, 
		obstacle_type = 2,
		power_up_type = 3
	};

	enum Team
	{
		no_team = 0,
		red_team = 1,	// the player side
		blue_team = 2	// the enemy side
	};

private:

	//each entity has a unique ID
	int         m_ID;

	//every entity has a type associated with it (health, troll, ammo etc)
	int         m_iType;

	int			m_iTeam;

	int			m_iLive;
	int			m_iHealth;

	bool		m_bDead;
	bool		m_bExpired;

	float		m_fExpireDuration;	
	float		m_fExpireTime;

	BaseGameEntity* m_Killer;

	//this is the next valid ID. Each time a BaseGameEntity is instantiated
	//this value is updated
	static int  m_iNextValidID;

	//this must be called within each constructor to make sure the ID is set
	//correctly. It verifies that the value passed to the method is greater
	//or equal to the next valid ID, before setting the ID and incrementing
	//the next valid ID
	void SetID(int val);

protected:

	//its location in the environment
	Vector2D m_vPosition;
	//rotation
	float m_fRotation;

	// for bounding box
	Vector2D m_Size;
	// for bounding circle
	float m_Radius;

	Vector2D m_StartPosition;

	std::string m_SpriteURL;

	Simple2D::Image* m_Sprite;
	BaseGameEntity();

	BaseGameEntity(int ID, int Type, const std::string & SpriteURL, Vector2D Position, Vector2D StartPosition);


	void SetTeam(int teamID) { m_iTeam = teamID; }

	void SetLive(int Live) { m_iLive = Live; }

	// Try to get another live, reduce and return if it still has live.
	bool GetAnotherLive() { m_iLive--; return m_iLive > 0; }

	void SetHealth(int Health) { m_iHealth = Health; }

	virtual void RestoreEntity() { m_bDead = false; }
	virtual void Suicide() { m_bDead = true; }
public:
	NoParamEvent EntityCallback;

	virtual ~BaseGameEntity()
	{
		if (m_Sprite)
		{
			Simple2D::DestroyImage(m_Sprite);
		}
	}
	//implement base class Update
	virtual void Update();

	//implement base class Render
	virtual void Render();
	

	//use this to grab the next valid ID
	static int   GetNextValidID() { return m_iNextValidID; }

	//this can be used to reset the next ID
	static void  ResetNextValidID() { m_iNextValidID = 0; }

	Vector2D     Pos()const { return m_vPosition; }
	void         SetPos(Vector2D new_pos) { m_vPosition = new_pos; }
	Vector2D	 Size()const {	return  m_Size;	}
	bool		 UpdateBody(std::string imageURL);
	bool		 UpdateBody(Simple2D::Image* pImage);

	void		 PostUpdateImage();
	bool		 IsDead() const { return m_bDead;}
	void		 SetExpired() { m_bExpired = true; }
	bool		 IsExpired() const { return m_bExpired; }
	float		 ExpireTime() const{ return m_fExpireTime; }
	const BaseGameEntity* GetKiller() const { return m_Killer; }
	int          ID()const { return m_ID; }

	int          EntityType()const { return m_iType; }
	void         SetEntityType(int new_type) { m_iType = new_type; }
	int			 EntityTeam()const { return m_iTeam; }
	int			 EntityLive()const { return m_iLive; }
	int			 EntityHealth()const { return m_iHealth; }

	// Apply damage and return if the entity is dead.
	virtual bool ApplyDamage(int DamageVal = 1, BaseGameEntity* Instigator = nullptr);
	virtual float OnDead();

};

#endif