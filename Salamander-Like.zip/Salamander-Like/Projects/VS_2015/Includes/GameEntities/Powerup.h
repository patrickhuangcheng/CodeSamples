#ifndef POWERUP_H
#define POWERUP_H

#include "misc/autolist.h"
#include "MovingEntity.h"

class Powerup : public MovingEntity,
				public AutoList<Powerup>
{
public:
	Powerup(
		Vector2D position
	) : MovingEntity(
		power_up_type,
		position, 
		GameConfig::POWERUPSPEED,
		GameConfig::UpgradeTex)

	{}
	virtual ~Powerup();

	void Update();

};

#endif