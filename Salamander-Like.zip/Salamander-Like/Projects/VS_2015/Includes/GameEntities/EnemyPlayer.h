#ifndef ENEMY_PLAYER_H
#define ENEMY_PLAYER_H
#include <map>
#include "misc\autolist.h"
#include "PlayerBase.h"
#include "GameEntities\BulletEntity.h"
#include "Delegate.h"

class TimeManager;

class EnemyPlayer : public PlayerBase,
					public AutoList<EnemyPlayer>
{
public:
	enum LEVEL { drone, feeder, carrier };

	class EnemyDNA
	{// encapsulation of the generation info

	public:
		EnemyDNA() :SpawnPosition(Vector2D()), Level(EnemyPlayer::LEVEL::drone), ExpireTime(-1.f) {}

		EnemyDNA(Vector2D position, EnemyPlayer::LEVEL level, float InExpireTime)
			:SpawnPosition(position),
			Level(level),
			ExpireTime(InExpireTime)
		{}

		EnemyDNA(const EnemyDNA &rhs)
			:SpawnPosition(rhs.SpawnPosition), Level(rhs.Level), ExpireTime(rhs.ExpireTime)
		{}

		const EnemyDNA& operator=(const EnemyDNA &rhs)
		{
			SpawnPosition = rhs.SpawnPosition;
			Level = rhs.Level;
			ExpireTime = rhs.ExpireTime;
			return *this;
		}

		~EnemyDNA() {}

		Vector2D SpawnPosition;
		EnemyPlayer::LEVEL Level;
		float	ExpireTime;
	};

	EnemyPlayer(Vector2D position,LEVEL level, TimeManager* TM = nullptr) : PlayerBase(position, GameConfig::ENEMYSPEED[level], GameConfig::EnemyTexes[level]),
		ActionChanger(TM)
	{
		m_DNA = EnemyDNA(position, level, Simple2D::GetGameTime());
		ExplosionImage = Simple2D::CreateImage(GameConfig::ExplosionTexes[level]);
		SetHealth(m_DNA.Level + 1);
	}

	EnemyPlayer(const EnemyDNA& DNA, TimeManager* TM = nullptr) : PlayerBase(DNA.SpawnPosition, GameConfig::ENEMYSPEED[DNA.Level], GameConfig::EnemyTexes[DNA.Level]),
		ActionChanger(TM)
	{
		m_DNA = DNA;
		ExplosionImage = Simple2D::CreateImage(GameConfig::ExplosionTexes[m_DNA.Level]);
		SetHealth(m_DNA.Level+1);
	}

	EnemyPlayer(const EnemyPlayer &rhs, TimeManager* TM = nullptr) :PlayerBase(rhs.GetDNA().SpawnPosition, GameConfig::ENEMYSPEED[rhs.GetDNA().Level], GameConfig::EnemyTexes[rhs.GetDNA().Level]),
		ActionChanger(TM)
	{
		m_DNA = rhs.GetDNA();
		ExplosionImage = Simple2D::CreateImage(GameConfig::ExplosionTexes[m_DNA.Level]);
		SetHealth(m_DNA.Level + 1);
	}

	EnemyPlayer& operator=(const EnemyPlayer &rhs)
	{	
		ActionChanger = rhs.ActionChanger;
		m_DNA = rhs.GetDNA();
		ExplosionImage = rhs.ExplosionImage;
		return *this;
	}

	void Update();
	
	virtual ~EnemyPlayer() 
	{
		if (ActionChanger != nullptr)
			delete ActionChanger;
	};

	virtual bool ApplyDamage(int DamageVal = 1, BaseGameEntity* Instigator = nullptr);

	virtual float OnDead();

	virtual void Suicide();

	const EnemyDNA& GetDNA() const { return m_DNA; }

	bool IsEarly(const EnemyPlayer & rhs)
	{
		return this->GetDNA().ExpireTime < rhs.GetDNA().ExpireTime;
	}

protected:
	TimeManager* ActionChanger;
	
private:
	EnemyDNA	m_DNA;
	
};


class Drone : public EnemyPlayer
{
public:
	Drone(const EnemyDNA& DNA) 
		:EnemyPlayer(DNA,
		new TimeManager(MakeVoidDelegate(this, &Drone::FlipflopYVelocity), Simple2D::GetGameTime(), 2.f, true))
	{}

	static EnemyPlayer* __stdcall Create(const EnemyDNA& DNA) {
		return new Drone(DNA);
	}

private:
	void FlipflopYVelocity()
	{
		m_vVelocity = Vector2D(m_vVelocity.x, m_vVelocity.y * -1);
	}
};

class Feeder : public EnemyPlayer
{
public:
	Feeder(const EnemyDNA& DNA) :EnemyPlayer(DNA) {}

	static EnemyPlayer* __stdcall Create(const EnemyDNA& DNA) {
		return new Feeder(DNA);
	}
};

class Carrier : public EnemyPlayer
{
public:
	Carrier(const EnemyDNA& DNA) :EnemyPlayer(DNA,
		new TimeManager(MakeVoidDelegate(this, &Carrier::ShootBullet), Simple2D::GetGameTime(), 2.f, true))
	{}

	static EnemyPlayer* __stdcall Create(const EnemyDNA& DNA) {
		return new Carrier(DNA);
	}

private:
	
	void ShootBullet()
	{
		new BulletEntity(Pos() + Vector2D(m_Size.x * -1 / 2, +18.f),
			GameConfig::BULLETSPEED* -0.5f,
			GameConfig::BulletTexes[1],
			this);

		new BulletEntity(Pos() + Vector2D(m_Size.x * -1/ 2, -18.f),
			GameConfig::BULLETSPEED* -0.5f,
			GameConfig::BulletTexes[1],
			this);

		new BulletEntity(Pos() + Vector2D(m_Size.x * -1 / 2, 0.f),
			GameConfig::BULLETSPEED* -0.5f,
			GameConfig::BulletTexes[1],
			this);
	}
};

//////////////////////////////////////////////////////////////////////////
//EnemyFactory
typedef EnemyPlayer* (__stdcall *CreateEnemyFn)(const EnemyPlayer::EnemyDNA&);

class EnemyFactory {
private:
	EnemyFactory();
	EnemyFactory(const EnemyFactory&) {}
	EnemyFactory &operator= (const EnemyFactory &) { return *this; }

	typedef std::map<EnemyPlayer::LEVEL, CreateEnemyFn> FactoryMap;
	FactoryMap m_FactoryMap;
public:
	~EnemyFactory() { m_FactoryMap.clear(); }

	static EnemyFactory *Get()
	{
		static EnemyFactory instance;
		return &instance;
	}

	void Register(EnemyPlayer::LEVEL level, CreateEnemyFn pfnCreate);
	EnemyPlayer* CreateEnemy(const EnemyPlayer::EnemyDNA& DNA);
};

#endif
