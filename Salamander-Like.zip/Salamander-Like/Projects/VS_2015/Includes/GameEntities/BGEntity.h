#ifndef BG_ENTITY_H
#define BG_ENTITY_H
#include "MovingEntity.h"

class BGEntity : public MovingEntity
{
public:
	BGEntity(Vector2D startPosition,
		Vector2D resetPosition,
		Vector2D velocity,
		Vector2D ClampX,
		const std::string& SpriteURL,float Scale = 1.f) 
		:MovingEntity(default_entity_type, startPosition, velocity, SpriteURL),
		m_ClampX(ClampX),
		m_ResetPosition(resetPosition),
		m_fScale(Scale),
		m_TheOtherBGImage(nullptr),
		m_isBGUpdate(false)
	{}

	virtual ~BGEntity() {}

	void Update()
	{
		if (!m_isBGUpdate) return;
		
		
		if (m_Sprite && !MovingEntity::IsReachedOtherSideofScr(m_ClampX))
		{
			AddMovement();
		}
		else
		{
			if (m_TheOtherBGImage == nullptr)
			{
				this->SetPos(Vector2D(m_ResetPosition.x /*+ m_Size.x*/, m_ResetPosition.y));
			}
			else 
			{
				m_isBGUpdate = false;
				return;
			}
		}

		if (m_TheOtherBGImage && MovingEntity::IsReachedOtherSideofScr(m_ClampX + GameConfig::STARLAYEROFFSET))
		{
			m_TheOtherBGImage->SetPos(Vector2D(m_vPosition.x + m_Size.x, m_vPosition.y));
			m_TheOtherBGImage->EnableBGUpdate();
		}
	}

	void Render()
	{
		if (m_Sprite)
		{
			Simple2D::DrawImage(m_Sprite, m_vPosition.x, m_vPosition.y, m_fRotation, m_fScale);
		}
	}

	void SetTheOtherBGImage(BGEntity* NextBGImage)
	{
		m_TheOtherBGImage = NextBGImage;
	}

	void EnableBGUpdate() { m_isBGUpdate = true; }
	bool GetIsBGUpdate() { return m_isBGUpdate; }
private:
	Vector2D m_ClampX;
	Vector2D m_ResetPosition;
	float m_fScale;
	BGEntity* m_TheOtherBGImage;
	bool m_isBGUpdate;

};
#endif