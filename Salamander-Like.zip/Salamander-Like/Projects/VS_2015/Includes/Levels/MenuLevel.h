#ifndef MENU_LEVEL_H
#define MENU_LEVEL_H

#include "Level.h"
class MenuLevel :public Level
{
public:
	MenuLevel(int cxClient, int cyClient)
		:Level(cxClient, cyClient)
	{};
	virtual ~MenuLevel() {};
	virtual void Update()
	{
		if (Simple2D::IsKeyPressed(Simple2D::KEY_SPACE))
		{
			if (!Started())
			{
				SetStartLevel(true);
				StartLevelCallback();
			}
		}
	}
	virtual void Render() {};
protected:
	virtual void PostInitLevel()
	{
		Level::PostInitLevel();
	}
	virtual void LevelFinished() {};
public:
	virtual void ResetLevel() {};
};

#endif