#ifndef PLAY_LEVEL_H
#define PLAY_LEVEL_H
#include "Level.h"

class MovingEntity;
class EnemyPlayer;
class WaveSpawner;
class PlayLevel :public Level
{
public:
	PlayLevel(int cxClient, int cyClient)
		:Level(cxClient, cyClient),
		m_fLevelFinishTime(0),
		pPlayer(nullptr),
		pBGImage{ nullptr, nullptr, nullptr },
		pWaveSpawner(nullptr)
	{
		PostInitLevel();
	};

	virtual ~PlayLevel();
	virtual void Update();
	virtual void Render();
protected:
	virtual void PostInitLevel();
	virtual void LevelFinished();

public:
	virtual void ResetLevel();
private:
	float m_fLevelFinishTime;
	MovingEntity* pPlayer;
	MovingEntity* pBGImage[3];
	WaveSpawner* pWaveSpawner;
	bool ClearLevel();
};

#endif