#ifndef LEVEL_H
#define LEVEL_H

#include "Delegate.h"

class Level
{

public:
	Level(int cxClient, int cyClient)
		:	m_bStarted(false),
			m_cxClient(cxClient),
			m_cyClient(cyClient)
	{};
	virtual ~Level() 
	{

	};
	virtual void Update() = 0;
	virtual void Render() = 0;

	void  SetStartLevel(bool IsStart) { m_bStarted = IsStart; }
	bool  Started() { return m_bStarted; }

	NoParamEvent StartLevelCallback;

protected:
	// indicates if the game is paused
	bool m_bStarted;

	//local copy of client window dimensions
	int m_cxClient,
		m_cyClient;

	virtual void PostInitLevel() {m_bStarted = true;}
	virtual void LevelFinished()= 0;
public:
	virtual void ResetLevel() = 0;
};

#endif
