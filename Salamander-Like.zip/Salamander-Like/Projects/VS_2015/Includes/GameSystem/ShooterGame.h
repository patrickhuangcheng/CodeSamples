#ifndef SHOOTER_GAME_H
#define SHOOTER_GAME_H
//------------------------------------------------------------------------
//
//  Name: ShooterGame.h
//
//  Desc: Game level
//
//  Author: HUANG Cheng
//
//------------------------------------------------------------------------

#include <map>

#include "2D/Vector2D.h"
#include "Simple2D.h"
#include "Delegate.h"

namespace GameConfig 
{

	enum Positions { None, NorthWest, North, NorthEast, East, Center, West, SouthWest, South, SouthEast	};


	//HUD
	static const Vector2D SCREENSIZE(1024.f, 768.f);
	static const Vector2D SCORE_HUD(100.f, 750.f);

	//Player & Enemy
	static const Vector2D PLAYERSPEED(5.f, 5.f);
	static const Vector2D PLAYERRESTORESPEED(5.f, 0.f);
	static const Vector2D PLAYERSTART(256.f, 384.f);
	static const int PLAYERMAXGRADE = 3;
	static const int PLAYERMAXLIVE = 3;


	static const int MAXPLAYERAMMO[3] = { -1, 50, 100};
	static const Vector2D ENEMYSPEED[3] = { Vector2D(-2.5f, 1.5f),
											Vector2D(-2.f, 1.f),
											Vector2D(-1.5f, 0.5f) };
	static const int ENEMYMAXGRADE = 3;
	static const int ENEMYMAXLIVE = 1;
	static const Vector2D BULLETSPEED(8.f, 0.f);

	// Clamps
	// ClampX:(Left Boundary, Right Boundary)
	// ClampY:(Upper Boundary, Lower Boundary)

	static const Vector2D PLAYERCLAMPX[3] = {	Vector2D(50.f, 950.f),
												Vector2D(65.f, 935.f),
												Vector2D(71.5f, 928.5f)	};
	static const Vector2D PLAYERCLAMPY[3] = {	Vector2D(100.f, 670.f),
												Vector2D(105.f, 665.f),
												Vector2D(117.f, 653.f) };
	static const Vector2D ENEMYCLAMPY[3] = {	Vector2D(100.f, 680.f),
												Vector2D(100.f, 680.f),
												Vector2D(160.f, 620.f) };
	static const int EnemyWidth[9] = { 150, 250, 350, 450, 550, 650, 750, 850, 950 };
	static const int EnemyHeight[9] = { 100, 170, 240, 310, 380, 450, 520, 590, 660 };

	static const Vector2D ACTORCLAMPX(-300.f, 1300.f);
	static const Vector2D ACTORCLAMPY(100.f, 670.f);

	// BG Properties
	static const Vector2D STARLAYERCLAMPX(-768.f, 2048.f);
	static const Vector2D STARLAYERSTART(768.f, 384.f);
	static const Vector2D STARLAYERRIGHT(1792.f, 384.f);
	static const Vector2D STARLAYEROFFSET(959.f, 0.f);
	static const Vector2D STARLAYERVELOCITY(-4.f, 0.f);
	static const Vector2D MOONLAYERRIGHT(1500.f, 384.f);
	static const Vector2D MOONLAYERVELOCITY(-0.3f, 0.f);

	static const float FIREGAP[3] = { 0.3f, 0.2f, 0.1f };
	static const Vector2D METEOSPEED[4] = { Vector2D(-1.2f, 0.f),
											Vector2D(-0.8f, 0.f),
											Vector2D(-0.8f, 0.f),
											Vector2D(-0.5f, 0.f) };
	static const float METEOROTATION[] = { 0.5f, 0.3f, 0.3f, 0.2f };
	static const Vector2D POWERUPSPEED(-0.5f, 0.f);

	//System Variables
	static const std::string TextureFolderURL = "../../Content/Textures/";
	static const std::string FontFolderURL = "../../Content/Fonts/";

	// Assets PNGs
	static const std::string PlayerTexes[3] = { TextureFolderURL + "Player_1.png",
												TextureFolderURL + "Player_2.png",
												TextureFolderURL + "Player_3.png" };

	static const std::string EnemyTexes[3] = {	TextureFolderURL + "Enemy_1.png",
												TextureFolderURL + "Enemy_2.png",
												TextureFolderURL + "Enemy_3.png" };

	static const std::string MeteoriteTexes[4] = {	TextureFolderURL + "Meteorite_3.png",
													TextureFolderURL + "Meteorite_1.png",
													TextureFolderURL + "Meteorite_2.png",
													TextureFolderURL + "Meteorite_4.png" };

	static const std::string ExplosionTexes[3] = {	TextureFolderURL + "Explosion_1.png",
													TextureFolderURL + "Explosion_1.png",
													TextureFolderURL + "Explosion_2.png" };

	static const std::string BulletTexes[2] = { TextureFolderURL + "PlayerBullet.png",
												TextureFolderURL + "EnemyBullet.png" };

	static const std::string MoonTex =		TextureFolderURL + "Moon.png";
	static const std::string StarLayerTex = TextureFolderURL + "StarLayer.png";
	static const std::string UpgradeTex =	TextureFolderURL + "Upgrade.png";

	// Assets Fonts
	static const std::string AGENCYBFont = FontFolderURL + "AGENCYB.TTF";

	// Debug mode option
	const bool m_bDebug = false;

	static const std::map<int, int> PRDExpectations = { {5, 380}, {10, 1475}, {15, 3221}, {20, 5570}, {25, 8475}, {30, 11895} };

}



class Level;
class ShooterGame
{
public:
	ShooterGame();
	~ShooterGame();

	void Update();

	bool  GameOn() { return m_bGameOn; }
	

private:
	// indicates if the game is start

	bool m_bGameOn;

	Simple2D::Window* pWindow;
	Level* m_pMenuLevel;
	Level* m_pPlayLevel;
	Level* pCurLevel;
	void  SetGameOn() { m_bGameOn = true; }
	void  SetGameOff() { m_bGameOn = false; }

	void Render();	

	void StartPlayLevel();
	void StartMenuLevel();
	void GameOverToMenu();
};

#endif