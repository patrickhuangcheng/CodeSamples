#ifndef HUD_H
#define HUD_H

#include "GameSystem\ShooterGame.h"

class HUDText {

public:
	HUDText(int FontSize = 10, Vector2D Pos = Vector2D(150.f, 10.0f), const std::string& Context = "HUDText", float Rot = 0.f, float Scale = 1.f):
		m_FontSize(FontSize),
		m_Pos(Pos),
		m_Rot(Rot),
		m_fScale(Scale),
		m_Context(Context),
		m_pFont(Simple2D::CreateFont(GameConfig::AGENCYBFont, FontSize))
	{}
	~HUDText()
	{
		DestroyFont(m_pFont);
	}
	
	void UpdateContext(const std::string& Context)
	{
		m_Context = Context;
	}

	void UpdateContext(std::string&& Context)
	{
		m_Context = std::move(Context);
	}

	const std::string& GetContext() const
	{
		return m_Context;
	}

	void Render()
	{
		Simple2D::DrawString(m_pFont, m_Context, m_Pos.x, m_Pos.y, m_Rot, m_fScale);
	}
private:
	int m_FontSize;
	Vector2D m_Pos;
	float m_Rot, m_fScale;
	std::string m_Context;
	Simple2D::Font* m_pFont;
};

class HUD {
public:
	enum State {none, welcome, ingame, over};

private:

	HUD() :
		m_State(none),
		m_iLive(0),
		m_iScore(0),
		m_iAmmo(0),
		m_bRefreshed(true),
		PlayerContext(" "),
		DebugContext("Debug Context"),
		pDebugContext(&PlayerContext),
		pPlayerHUD(new HUDText(20, Vector2D(200.f, 750.f), PlayerContext)),
		pPlayerHUDDebug(new HUDText(20, Vector2D(250.f, 30.f), "Directions: ASDW / Arrow keys; Fire: Space / Ctrl / J key ")),
		pTitleTextes{ 
		new HUDText(120, Vector2D(300.f, 560.f), "Fly",5.f,3.f),
		new HUDText(120, Vector2D(550.f, 460.f), "And", 5.f, 1.f),
		new HUDText(120, Vector2D(700.f, 240.f), "Fight", 5.f, 3.f),
		new HUDText(30, Vector2D(210.f, 240.f), "A GAME BY HUANG CHENG ", 0.f, 1.3f),
		new HUDText(30, Vector2D(210.f, 180.f), "Press Space to Start", 0.f, 1.f) 
		},
		pOverTextes{
		new HUDText(120, Vector2D(400.f, 560.f), "Game", 5.f, 3.f),
		new HUDText(120, Vector2D(700.f, 240.f), "Over", 5.f, 3.f),
		new HUDText(30, Vector2D(210.f, 240.f), "Thanks for playing", 0.f, 1.5f)
		}
	{}
public:
	static HUD& GetInstance()
	{
		static HUD instance;
		return instance;
	}
	HUD(HUD const&)				= delete;
	void operator=(HUD const&)  = delete;

	void Update() {}

	void Render()
	{
		switch (m_State)
		{
		case HUD::none:
			break;
		case HUD::welcome:
			for (auto&& t : pTitleTextes) t->Render();
			break;
		case HUD::ingame:
			if (pPlayerHUD)
			{
				if (m_bRefreshed)
				{
					PlayerContext = "Lives: " + std::to_string(m_iLive) + "     Score: " + std::to_string(m_iScore) + "     Ammo: " + (m_iAmmo >= 0 ? std::to_string(m_iAmmo) : " Infinite");
					pPlayerHUD->UpdateContext(PlayerContext);
					m_bRefreshed = false;
				}
				pPlayerHUD->Render();
			}
			break;
		case HUD::over:
			for (auto&& t : pOverTextes) t->Render();
			break;
		}
		if (GameConfig::m_bDebug && pPlayerHUDDebug)
		{
			pPlayerHUDDebug->UpdateContext(DebugContext);
			pPlayerHUDDebug->Render();
		}
		else
		{
			pPlayerHUDDebug->Render();
		}
	}
	
	void ShowHUD(State state) { m_State = state;}

	void UpdateLive(int Num) {
		m_iLive = Num; 
		m_bRefreshed = true;
	}
	void AddScore(int Num) { 
		m_iScore += Num;
		m_bRefreshed = true;
	}

	void ResetScore() {
		m_iScore = 0;
		m_bRefreshed = true;
	}
	void UpdateAmmo(int Num) {
		m_iAmmo = Num;
		m_bRefreshed = true;
	}


	void UpdateDebug(const std::string& pinfo) {
		DebugContext = pinfo;
	}

private:
	State m_State;
	int m_iLive;
	int m_iScore;
	int m_iAmmo;
	bool m_bRefreshed;
	std::string PlayerContext;
	std::string DebugContext;
	std::string* pDebugContext;
	HUDText* pPlayerHUD;
	HUDText* pPlayerHUDDebug;
	HUDText* pTitleTextes[5];
	HUDText* pOverTextes[3];
};
#endif