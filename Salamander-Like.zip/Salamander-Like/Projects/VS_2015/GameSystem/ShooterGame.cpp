#include "GameSystem\ShooterGame.h"
#include "Levels\MenuLevel.h"
#include "Levels\PlayLevel.h"
#include "UI\HUD.h"

ShooterGame::ShooterGame() : 
	m_bGameOn(true),
	pWindow(Simple2D::CreateWindow("ShooterGame", (int)GameConfig::SCREENSIZE.x, (int)GameConfig::SCREENSIZE.y)),
	m_pMenuLevel(new MenuLevel((int)GameConfig::SCREENSIZE.x, (int)GameConfig::SCREENSIZE.y)),
	m_pPlayLevel(new PlayLevel((int)GameConfig::SCREENSIZE.x, (int)GameConfig::SCREENSIZE.y)),
	pCurLevel(nullptr)
{
	m_pMenuLevel->StartLevelCallback = MakeVoidDelegate(this, &ShooterGame::StartPlayLevel);
	m_pPlayLevel->StartLevelCallback = MakeVoidDelegate(this, &ShooterGame::StartMenuLevel);
	StartMenuLevel();
}

ShooterGame::~ShooterGame()
{
	delete m_pMenuLevel;
	delete m_pPlayLevel;
	Simple2D::DestroyWindow(pWindow);
}

void ShooterGame::Update()
{
	if (pWindow && !Simple2D::ShouldWindowClose(pWindow))
	{
		if (pCurLevel) pCurLevel->Update();
		HUD::GetInstance().Update();
		Render();
	}
	else
	{
		SetGameOff();
	}
}

void ShooterGame::Render()
{
	if (pWindow)	Simple2D::RefreshWindowBuffer(pWindow);
	if (pCurLevel)	pCurLevel->Render();
	HUD::GetInstance().Render();
}

void ShooterGame::StartPlayLevel()
{
	if (m_pPlayLevel)
	{
		pCurLevel = m_pPlayLevel;
		pCurLevel->ResetLevel();
	}
	HUD::GetInstance().ShowHUD(HUD::ingame);
}

void ShooterGame::StartMenuLevel()
{
	if (m_pMenuLevel)
	{
		pCurLevel = m_pMenuLevel;
		pCurLevel->SetStartLevel(false);
		HUD::GetInstance().ShowHUD(HUD::welcome);
	}
}

void ShooterGame::GameOverToMenu()
{

}
