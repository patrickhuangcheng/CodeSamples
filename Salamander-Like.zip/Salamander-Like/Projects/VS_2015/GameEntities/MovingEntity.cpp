#include "GameEntities\MovingEntity.h"

MovingEntity::~MovingEntity()
{

}

void MovingEntity::AddMovement()
{
	m_vPosition += m_vVelocity;
}

void MovingEntity::AddMovement(const Vector2D & delta_pos)
{
	m_vPosition += delta_pos;
	if (!m_vClampX.isZero())
	{
		Clamp(m_vPosition.x, m_vClampX.x, m_vClampX.y);
	}
	if (!m_vClampY.isZero())
	{
		Clamp(m_vPosition.y, m_vClampY.x, m_vClampY.y);
	}
}

bool MovingEntity::IsReachedOtherSideofScr(const Vector2D& ClampX, bool IsFromRightToLeft/* = true*/)
{
	if (ClampX.isZero())
		return false;
	if (IsFromRightToLeft)
	{
		return m_vPosition.x < ClampX.x;
	}
	else return m_vPosition.x > ClampX.x;
}

bool MovingEntity::IsWithinScrHeight(const Vector2D& ClampY)
{
	return m_vPosition.y > ClampY.x	&& m_vPosition.y < ClampY.y;
}

bool MovingEntity::IsOverlapped(const MovingEntity &other)
{
	if (IsBoundingCircleOverlap(other))
		return true;
	else
		return IsBoundingBoxOverlap(other);
}

bool MovingEntity::IsOverlapped(MovingEntity const *other)
{
	if (IsBoundingCircleOverlap(*other))
		return true;
	else
		return IsBoundingBoxOverlap(*other);
}

bool MovingEntity::IsWithinScreen()
{
	if (m_vClampX.isZero() && m_vClampY.isZero()) return true;
	if (Pos().x - Size().x / 2 < m_vClampX.x || Pos().x + Size().x / 2 > m_vClampX.y) return false;
	if (Pos().y + Size().y / 2 < m_vClampY.x || Pos().y - Size().y / 2 > m_vClampY.y) return false;

	return true;
}

bool MovingEntity::IsBoundingBoxOverlap(const MovingEntity &other)
{// AABB center mode
	if (m_vPosition.x + m_Size.x / 2 >= other.m_vPosition.x - other.m_Size.x / 2 &&
		m_vPosition.x - m_Size.x / 2 <= other.m_vPosition.x + other.m_Size.x / 2 &&
		m_vPosition.y + m_Size.y / 2 >= other.m_vPosition.y - other.m_Size.y / 2 &&
		m_vPosition.y - m_Size.y / 2 <= other.m_vPosition.y + other.m_Size.y / 2)
	{
		return true;
	}
	return false;
}

bool MovingEntity::IsBoundingCircleOverlap(const MovingEntity &other)
{// Circle Circle collision
	float r = m_Radius + other.m_Radius;
	r *= r;
	return r > pow((m_vPosition.x + other.m_vPosition.x), 2) + pow((m_vPosition.y + other.m_vPosition.y), 2);
}