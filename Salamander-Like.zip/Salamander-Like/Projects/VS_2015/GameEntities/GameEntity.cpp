#include "GameEntities\GameEntity.h"

int BaseGameEntity::m_iNextValidID = 0;

//------------------------------ ctor -----------------------------------------
//-----------------------------------------------------------------------------


BaseGameEntity::BaseGameEntity() :
	m_iType(default_entity_type),
	m_iTeam(no_team),
	m_iLive(1),
	m_iHealth(1),
	m_bDead(false),
	m_bExpired(false),
	m_fExpireDuration(0.5f),
	m_fExpireTime(-1.f),
	m_Killer(nullptr),
	m_vPosition(Vector2D(0, 0)),
	m_fRotation(0.f),
	m_StartPosition(Vector2D(0, 0)),
	m_SpriteURL(NULL),
	m_Sprite(nullptr)
{
	SetID(m_iNextValidID);
}

BaseGameEntity::BaseGameEntity(int ID, int Type, const std::string & SpriteURL, Vector2D Position, Vector2D StartPosition):
										m_iType(Type),
										m_iTeam(no_team),
										m_iLive(1),
										m_iHealth(1),
										m_bDead(false),
										m_bExpired(false),
										m_fExpireDuration(0.5f),
										m_fExpireTime(-1.f),
										m_Killer(nullptr),
										m_vPosition(Position),
										m_fRotation(0.f),
										m_StartPosition(StartPosition),
										m_SpriteURL(SpriteURL),
										m_Sprite(Simple2D::CreateImage(SpriteURL))
{
	SetID(ID);
	PostUpdateImage();

}


void BaseGameEntity::Update()
{
	if (m_bExpired) return;

	if (m_fExpireTime >= 0
		&& Simple2D::GetGameTime() - m_fExpireTime >= m_fExpireDuration)
	{
		m_bExpired = true;
	}
}

void BaseGameEntity::Render()
{
	if (m_Sprite)
	{
		Simple2D::DrawImage(m_Sprite, m_vPosition.x, m_vPosition.y, m_fRotation);
	}
}

bool BaseGameEntity::UpdateBody(std::string imageURL)
{
	Simple2D::Image* pImage = Simple2D::CreateImage(imageURL);
	return UpdateBody(pImage);
}

bool BaseGameEntity::UpdateBody(Simple2D::Image* pImage)
{
	if (!pImage)	return false;
	if (m_Sprite)	Simple2D::DestroyImage(m_Sprite);
	m_Sprite = pImage;
	PostUpdateImage();
	return true;
}

void BaseGameEntity::PostUpdateImage()
{
	if (m_Sprite)
	{
		int BGWidth = 0;
		int BGHeight = 0;
		Simple2D::GetImageSize(m_Sprite, &BGWidth, &BGHeight);
		m_Size.x = (float)BGWidth;
		m_Size.y = (float)BGHeight;
		m_Radius = sqrtf(powf((m_Size.x / 2), 2.f) + powf((m_Size.y / 2), 2.f));
	}
}

bool BaseGameEntity::ApplyDamage(int DamageVal /*= 1*/, BaseGameEntity* Instigator/* = nullptr*/)
{
	if (m_bDead) return true;	// when it's dead, it's dead;

	m_iHealth -= DamageVal;
	m_bDead = m_iHealth <= 0;
	if (m_bDead)
	{
		OnDead();
		m_Killer = Instigator;
	}
	return   m_bDead;
}

float BaseGameEntity::OnDead()
{
	m_fExpireTime = Simple2D::GetGameTime();
	return m_fExpireTime;
}


//----------------------------- SetID -----------------------------------------
//
//  this must be called within each constructor to make sure the ID is set
//  correctly. It verifies that the value passed to the method is greater
//  or equal to the next valid ID, before setting the ID and incrementing
//  the next valid ID
//-----------------------------------------------------------------------------
void BaseGameEntity::SetID(int val)
{
	//make sure the val is equal to or greater than the next available ID
	assert((val >= m_iNextValidID) && "<BaseGameEntity::SetID>: invalid ID");

	m_ID = val;

	m_iNextValidID = m_ID + 1;
}
