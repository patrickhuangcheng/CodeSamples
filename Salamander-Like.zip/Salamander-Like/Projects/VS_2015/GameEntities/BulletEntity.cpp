#include "GameEntities\BulletEntity.h"
void BulletEntity::Update()
{
	if (!IsReachedOtherSideofScr(GameConfig::ACTORCLAMPX))
	{
		AddMovement();
	}
	else
	{
		delete this;
	}
}
