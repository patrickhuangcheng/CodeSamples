#include "GameEntities\EnemyPlayer.h"
#include "GameEntities\Powerup.h"
#include "UI/HUD.h"


void EnemyPlayer::Update()
{
	BaseGameEntity::Update();
	ShowDebugPosition();
	if (!IsReachedOtherSideofScr(GameConfig::ACTORCLAMPX))
	{
		if (!IsWithinScrHeight(GameConfig::ENEMYCLAMPY[GetDNA().Level]))
		{
			if (m_vVelocity.y < 0 && Pos().y < (GameConfig::SCREENSIZE.y / 2))
			{
				m_vVelocity = GameConfig::ENEMYSPEED[m_DNA.Level];
			}
			if (m_vVelocity.y > 0 && Pos().y > (GameConfig::SCREENSIZE.y / 2))
			{
				m_vVelocity = Vector2D(GameConfig::ENEMYSPEED[m_DNA.Level].x, GameConfig::ENEMYSPEED[m_DNA.Level].y * -1);
			}
		}
		AddMovement();
	}
	else if(!IsDead())
	{
		Suicide();
	}
	if (ActionChanger)
		ActionChanger->Update(Simple2D::GetGameTime());
}




bool EnemyPlayer::ApplyDamage(int DamageVal /*= 1*/, BaseGameEntity* Instigator /*= nullptr*/)
{
	bool result = BaseGameEntity::ApplyDamage(DamageVal);
	if (result)
	{
		if(Instigator && m_DNA.Level == feeder && RandInt(0, 8) > 5)
			new Powerup(Vector2D(Pos()));
		else if (Instigator && m_DNA.Level == carrier)
			new Powerup(Vector2D(Pos()));

	}
	return result;
}

float EnemyPlayer::OnDead()
{
	UpdateBody(ExplosionImage);
	HUD::GetInstance().AddScore(300);
	m_DNA.ExpireTime = BaseGameEntity::OnDead();
	return ExpireTime();
}

void EnemyPlayer::Suicide()
{
	BaseGameEntity::Suicide();
	m_DNA.ExpireTime = BaseGameEntity::OnDead();
}

//////////////////////////////////////////////////////////////////////////
//EnemyFactory
EnemyFactory::EnemyFactory()
{
	Register(EnemyPlayer::drone, &Drone::Create);
	Register(EnemyPlayer::feeder, &Feeder::Create);
	Register(EnemyPlayer::carrier, &Carrier::Create);
}

void EnemyFactory::Register(EnemyPlayer::LEVEL level, CreateEnemyFn pfnCreate)
{
	m_FactoryMap[level] = pfnCreate;
}

EnemyPlayer* EnemyFactory::CreateEnemy(const EnemyPlayer::EnemyDNA& DNA)
{
	FactoryMap::iterator it = m_FactoryMap.find(DNA.Level);
	if (it != m_FactoryMap.end())
// 		return it->second(DNA);
		return it->second(DNA);
	return NULL;
}
