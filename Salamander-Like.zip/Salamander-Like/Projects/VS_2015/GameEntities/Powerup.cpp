#include "GameEntities\Powerup.h"

Powerup::~Powerup()
{

}

void Powerup::Update()
{
	AddMovement();
}
