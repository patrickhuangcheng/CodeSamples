#include "GameEntities\PlayerBase.h"
#include "GameEntities\BulletEntity.h"
#include "UI/HUD.h"
// for the enemy
PlayerBase::PlayerBase(Vector2D position, Vector2D velocity,
	const std::string &  SpriteURL) : MovingEntity(body_type, position, velocity, SpriteURL),
	isUPPressed(false),
	isDownPressed(false),
	isLeftPressed(false),
	isRightPressed(false),
	isFirePressed(false),
	m_Grade(LEVEL::newborn),
	m_State(none),
	m_MaxGrade(GameConfig::ENEMYMAXGRADE),
	m_MaxLive(GameConfig::ENEMYMAXLIVE),
	m_LastFireTime(Simple2D::GetGameTime()),
	m_DestroyedTime(0)
{
	SetTeam(blue_team);
}

// for the player
PlayerBase::PlayerBase(Vector2D position, Vector2D velocity,
	LEVEL level) : MovingEntity(body_type, position, velocity, GameConfig::PlayerTexes[level],
		GameConfig::PLAYERCLAMPX[level], GameConfig::PLAYERCLAMPY[level]),
	isUPPressed(false),
	isDownPressed(false),
	isLeftPressed(false),
	isRightPressed(false),
	isFirePressed(false),
	m_Grade(level),
	m_State(none),
	m_MaxGrade(GameConfig::PLAYERMAXGRADE),
	m_MaxLive(GameConfig::PLAYERMAXLIVE),
	m_Ammo(-1),
	m_LastFireTime(Simple2D::GetGameTime()),
	m_DestroyedTime(0),
	Up(Vector2D(0.f, 1.f)*m_vVelocity.y),
	Down(Vector2D(0.f, -1.f)* m_vVelocity.y),
	Left(Vector2D(-1.f, 0.f)* m_vVelocity.x),
	Right(Vector2D(1.f, 0.f)* m_vVelocity.x)
{
	SetTeam(red_team);
	ExplosionImage = Simple2D::CreateImage(GameConfig::ExplosionTexes[2]);
	SetLive(GameConfig::PLAYERMAXLIVE);
	OnRestoreEntity();
	HUD::GetInstance().ResetScore();
}

PlayerBase::~PlayerBase()
{
	if ((BaseGameEntity::Team)EntityTeam() == BaseGameEntity::Team::blue_team)
		return;

	if (ExplosionImage)
	{
		Simple2D::DestroyImage(ExplosionImage);
	}
}
void PlayerBase::Update()
{
	switch (m_State)
	{
	case PlayerBase::none:
		break;
	case PlayerBase::flyingToPlayerStart:
		m_vPosition += GameConfig::PLAYERRESTORESPEED;
		if (m_vPosition.x > GameConfig::PLAYERSTART.x)
		{
			RestoreEntity();
		}
		break;
	case PlayerBase::controlledByPlayer:
		DetectControl();
		UpdateControl();
		break;
	case PlayerBase::destroyed:
		if (Simple2D::GetGameTime() - m_DestroyedTime >= 1.f)
		{
			if (EntityLive() > 0)
				OnRestoreEntity(); 
			else
			{
				OnPlayerReallyDie();
			}
		}
		else
		{
			if (ExplosionImage) Simple2D::DrawImage(ExplosionImage, ExplotionImgPos.x, ExplotionImgPos.y);
		}
		break;
	}

	
}

void PlayerBase::Fire()
{
	if (Simple2D::GetGameTime() - m_LastFireTime >= GameConfig::FIREGAP[m_Grade])
	{
		m_LastFireTime = Simple2D::GetGameTime();

		switch (m_Grade)
		{
		case PlayerBase::LEVEL::newborn :
			new BulletEntity(Pos() + Vector2D(m_Size.x / 2, 0),
				GameConfig::BULLETSPEED * 0.8f,
				GameConfig::BulletTexes[0],
				this);
			break;
		case PlayerBase::LEVEL::advance:
			if (!CheckAmmo()) return;

			new BulletEntity(Pos() + Vector2D(m_Size.x / 2, 0),
				GameConfig::BULLETSPEED * 1.6f,
				GameConfig::BulletTexes[0],
				this);
			
			break;
		case PlayerBase::LEVEL::ultimate:
			if (!CheckAmmo()) return;
			new BulletEntity(Pos() + Vector2D(m_Size.x / 2, 5.f),
				GameConfig::BULLETSPEED* 1.6f,
				GameConfig::BulletTexes[0],
				this);
			if (!CheckAmmo()) return;
			new BulletEntity(Pos() + Vector2D(m_Size.x / 2, -18.f),
				GameConfig::BULLETSPEED* 1.6f,
				GameConfig::BulletTexes[0],
				this);
			break;
		}
		
	}
}


void PlayerBase::Upgrade(int grade /*= 1*/)
{
	int level = (int)m_Grade + grade;
	Clamp(level, 0, 2);
	m_Grade = (PlayerBase::LEVEL)level;
	UpdateBody(GameConfig::PlayerTexes[level]);
	m_vClampX = GameConfig::PLAYERCLAMPX[level];
	m_vClampY = GameConfig::PLAYERCLAMPY[level];
	m_Ammo = GameConfig::MAXPLAYERAMMO[level];
	HUD::GetInstance().UpdateAmmo(m_Ammo);

}

void PlayerBase::DownGrade(int grade /*= 1*/)
{
	int level = (int)m_Grade - grade;
	Clamp(level, 0, 2);
	m_Grade = (PlayerBase::LEVEL)level;
	UpdateBody(GameConfig::PlayerTexes[level]);
	m_vClampX = GameConfig::PLAYERCLAMPX[level];
	m_vClampY = GameConfig::PLAYERCLAMPY[level];
	m_Ammo = GameConfig::MAXPLAYERAMMO[level];
	HUD::GetInstance().UpdateAmmo(m_Ammo);

}

bool PlayerBase::CheckAmmo()
{
	if (m_Grade > 0)
	{
		if (m_Ammo > 0)
		{
			m_Ammo--;
			HUD::GetInstance().UpdateAmmo(m_Ammo);
			return true;
		}
		else
		{
			DownGrade();
			return false;
		}
	}
	return true;
	
}

void PlayerBase::ShowDebugPosition()
{
	if (GameConfig::m_bDebug)
	{
		std::string DebugInfo = "X Pos: " + std::to_string(this->Pos().x) + "Y Pos: " + std::to_string(this->Pos().y);
		HUD::GetInstance().UpdateDebug(DebugInfo);
	}
}

float PlayerBase::OnDead()
{
	ResetControl();
	ExplotionImgPos = Pos();
	m_vPosition = Vector2D(-200.f, GameConfig::PLAYERSTART.y);
	GetAnotherLive();
	m_DestroyedTime = Simple2D::GetGameTime();
	m_State = destroyed;
	return m_DestroyedTime;
}

void PlayerBase::OnRestoreEntity()
{
	ResetControl();
	m_vPosition = Vector2D(10.f, GameConfig::PLAYERSTART.y);
	HUD::GetInstance().UpdateLive(EntityLive());
	HUD::GetInstance().UpdateAmmo(m_Ammo);

	if(EntityLive()>0)
		m_State = flyingToPlayerStart;
}

void PlayerBase::RestoreEntity()
{
	BaseGameEntity::RestoreEntity();
	m_State = controlledByPlayer;
}


void PlayerBase::OnPlayerReallyDie()
{
	HUD::GetInstance().ShowHUD(HUD::over);
	m_State = none;
	EntityCallback();
}

void PlayerBase::DetectControl()
{
	if (Simple2D::IsKeyPressed(Simple2D::KEY_W) || Simple2D::IsKeyPressed(Simple2D::KEY_UP_ARROW))
	{
		isUPPressed = true;
	}
	if (Simple2D::IsKeyReleased(Simple2D::KEY_W) || Simple2D::IsKeyReleased(Simple2D::KEY_UP_ARROW))
	{
		isUPPressed = false;
	}
	if (Simple2D::IsKeyPressed(Simple2D::KEY_S) || Simple2D::IsKeyPressed(Simple2D::KEY_DOWN_ARROW))
	{
		isDownPressed = true;
	}
	if (Simple2D::IsKeyReleased(Simple2D::KEY_S) || Simple2D::IsKeyReleased(Simple2D::KEY_DOWN_ARROW))
	{
		isDownPressed = false;
	}
	if (Simple2D::IsKeyPressed(Simple2D::KEY_A) || Simple2D::IsKeyPressed(Simple2D::KEY_LEFT_ARROW))
	{
		isLeftPressed = true;
	}
	if (Simple2D::IsKeyReleased(Simple2D::KEY_A) || Simple2D::IsKeyReleased(Simple2D::KEY_LEFT_ARROW))
	{
		isLeftPressed = false;
	}
	if (Simple2D::IsKeyPressed(Simple2D::KEY_D) || Simple2D::IsKeyPressed(Simple2D::KEY_RIGHT_ARROW))
	{
		isRightPressed = true;
	}
	if (Simple2D::IsKeyReleased(Simple2D::KEY_D) || Simple2D::IsKeyReleased(Simple2D::KEY_RIGHT_ARROW))
	{
		isRightPressed = false;
	}
	if (Simple2D::IsKeyPressed(Simple2D::KEY_CTRL) || Simple2D::IsKeyPressed(Simple2D::KEY_RIGHT_CTRL) || Simple2D::IsKeyPressed(Simple2D::KEY_CAPITAL_J) || Simple2D::IsKeyPressed(Simple2D::KEY_J)||Simple2D::IsKeyPressed((Simple2D::KEY_SPACE)))
	{
		isFirePressed = true;
	}
	if (Simple2D::IsKeyReleased(Simple2D::KEY_CTRL) || Simple2D::IsKeyReleased(Simple2D::KEY_RIGHT_CTRL) || Simple2D::IsKeyReleased(Simple2D::KEY_CAPITAL_J) || Simple2D::IsKeyReleased(Simple2D::KEY_J)||Simple2D::IsKeyReleased(Simple2D::KEY_SPACE))
	{
		isFirePressed = false;
	}
}

void PlayerBase::UpdateControl()
{
	if (isUPPressed)	AddMovement(Up);
	if (isDownPressed)	AddMovement(Down);
	if (isLeftPressed)	AddMovement(Left);
	if (isRightPressed)	AddMovement(Right);
	if (isFirePressed)	Fire();
}

void PlayerBase::ResetControl()
{
	isUPPressed = false;
	isDownPressed = false;
	isLeftPressed = false;
	isRightPressed = false;
	isFirePressed = false;
}

