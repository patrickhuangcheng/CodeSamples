#include "GameEntities\Meteorite.h"

Meteorite::~Meteorite()
{

}

void Meteorite::Update()
{
	AddMovement();
	m_fRotation += Rot;
}
