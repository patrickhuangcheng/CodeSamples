// #include "Simple2D.h"
#include "GameSystem\ShooterGame.h"

//--------------------------------- Globals ------------------------------
//
//------------------------------------------------------------------------

ShooterGame* g_ShooterGame;

int main(int argc, char *argv[])
{
	//////////////////////////////////////////////////////////////////////////
	//1. Create window;
	//2. Init Game : Import Assets;
	//3. Waiting for start;
	//4. Game Process;
	//5. Game Win/Lose, then go to Waiting for start
	//////////////////////////////////////////////////////////////////////////

	g_ShooterGame = new ShooterGame();

	while (g_ShooterGame && g_ShooterGame->GameOn())
	{
		g_ShooterGame->Update();
	}

	delete g_ShooterGame;
	
	return 0;
}

